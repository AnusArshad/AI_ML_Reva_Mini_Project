import numpy as np
import pandas as pd
import plotly.graph_objs as go
from sklearn.neighbors import KNeighborsRegressor

# Sample data (replace this with your actual data)
np.random.seed(0)
dates = pd.date_range('2022-01-01', periods=24, freq='M')  # 2 years of monthly data
revenue = np.random.randint(20000, 40000, size=24)

df = pd.DataFrame({'Date': dates, 'Revenue': revenue})

# Resample the data to a quarterly frequency
df_resampled = df.resample('Q', on='Date').mean()  # Quarterly average revenue

# KNN Model for Forecasting
X = np.arange(len(df_resampled)).reshape(-1, 1)  # Using the index as X
y = df_resampled['Revenue'].values
knn_model = KNeighborsRegressor(n_neighbors=3)
knn_model.fit(X, y)

# Forecasting next 4 quarters
forecast_X = np.arange(len(df_resampled), len(df_resampled) + 4).reshape(-1, 1)
forecast_revenue = knn_model.predict(forecast_X)

# Plotly Line Graph with Dots
fig = go.Figure()

# Plot actual quarterly revenue data
fig.add_trace(go.Scatter(
    x=df_resampled.index,
    y=df_resampled['Revenue'],
    mode='lines+markers',
    name='Actual Revenue'
))

# Plot forecasted revenue data (next 4 quarters)
forecast_dates = pd.date_range(df_resampled.index[-1] + pd.DateOffset(months=3), periods=4, freq='Q')
fig.add_trace(go.Scatter(
    x=forecast_dates,
    y=forecast_revenue,
    mode='lines+markers',
    name='Forecasted Revenue',
    line=dict(dash='dash', color='orange')  # Dotted line for forecast
))

# Layout settings
fig.update_layout(
    title='KNN Quarterly Revenue Forecast',
    xaxis_title='Date',
    yaxis_title='Revenue',
    height=400
)

# Show the figure
fig.show()
