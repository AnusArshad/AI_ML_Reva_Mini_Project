import pandas as pd
import numpy as np
import dash
from dash import dcc, html
import plotly.graph_objs as go
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline

# Load and prepare data
file_path = 'OnlineRetail.csv'  # Replace with your file path
df = pd.read_csv(file_path, encoding='ISO-8859-1')

# Data Preparation
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])
df['MonthYear'] = df['InvoiceDate'].dt.to_period('M')
df['Revenue'] = df['Quantity'] * df['UnitPrice']

# Aggregate Data for Enterprise Model
monthly_sales = df.groupby('MonthYear').agg({'Revenue': 'sum', 'Quantity': 'sum'}).reset_index()
monthly_sales['MonthYear'] = pd.to_datetime(monthly_sales['MonthYear'].astype(str))
monthly_sales['TimeID'] = np.arange(len(monthly_sales))  # Create numerical time ID

# Remove zero values for December and January 2012
monthly_sales = monthly_sales[~((monthly_sales['MonthYear'].dt.month == 12) &
                                (monthly_sales['MonthYear'].dt.year == 2012) &
                                (monthly_sales['Revenue'] == 0))]
monthly_sales = monthly_sales[~((monthly_sales['MonthYear'].dt.month == 1) &
                                (monthly_sales['MonthYear'].dt.year == 2012) &
                                (monthly_sales['Revenue'] == 0))]

# Moving Average
monthly_sales['Revenue_MA'] = monthly_sales['Revenue'].rolling(window=3).mean()

# Linear Regression Model for Forecasting Enterprise Revenue
X = monthly_sales[['TimeID']].values  # Convert to NumPy array
y = monthly_sales['Revenue'].values

# Define and fit the model
lin_model = make_pipeline(PolynomialFeatures(degree=2, include_bias=False), LinearRegression())
lin_model.fit(X, y)
monthly_sales['Forecasted_Revenue_Lin'] = lin_model.predict(X)

# Forecast future revenue up to April 2012
future_time_ids = np.arange(len(monthly_sales), len(monthly_sales) + 4).reshape(-1, 1)
future_months = pd.date_range(monthly_sales['MonthYear'].iloc[-1], periods=5, freq='ME')[1:]
future_forecast = lin_model.predict(future_time_ids)
future_sales = pd.DataFrame({'MonthYear': future_months, 'Forecasted_Revenue_Lin': future_forecast})

# Product-Level Model
product_sales = df.groupby(['StockCode', 'MonthYear']).agg({'Quantity': 'sum', 'Revenue': 'sum'}).reset_index()
product_sales['MonthYear'] = pd.to_datetime(product_sales['MonthYear'].astype(str))
product_sales['TimeID'] = product_sales.groupby('StockCode').cumcount()

# Linear Regression Model for Product-Level Forecast
product_models = {}
for product in product_sales['StockCode'].unique():
    product_data = product_sales[product_sales['StockCode'] == product]
    X_product = product_data[['TimeID']].values  # Convert to NumPy array
    y_product = product_data['Revenue'].values

    # Define and fit the model
    model = make_pipeline(PolynomialFeatures(degree=2, include_bias=False), LinearRegression())
    model.fit(X_product, y_product)
    product_models[product] = model

# Create future forecasts for products
product_forecasts = []
for product, model in product_models.items():
    last_time_id = product_sales[product_sales['StockCode'] == product]['TimeID'].max()
    future_time_ids_product = np.arange(last_time_id + 1, last_time_id + 5).reshape(-1, 1)
    future_forecast_product = model.predict(future_time_ids_product)
    future_sales_product = pd.DataFrame({'StockCode': product,
                                         'MonthYear': future_months,
                                         'Forecasted_Revenue_Lin': future_forecast_product})
    product_forecasts.append(future_sales_product)
product_forecasts = pd.concat(product_forecasts, ignore_index=True)

# Add revenue categories to the product forecasts
product_forecasts['Revenue_Category'] = pd.cut(product_forecasts['Forecasted_Revenue_Lin'],
                                               bins=[0, 10000, 20000, 30000, 40000, 50000, np.inf],
                                               labels=['0-10k', '10k-20k', '20k-30k', '30k-40k', '40k-50k', '50k+'])

# Count the number of products in each revenue category
category_counts = product_forecasts.groupby('Revenue_Category', observed=False)['StockCode'].nunique().reset_index()
category_counts.columns = ['Revenue Category', 'Number of Products']

# Combine past and future data for plotting
plot_data = pd.concat([monthly_sales, future_sales], ignore_index=True)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the CSS styles
styles = {
    'container': {
        'maxWidth': '1200px',
        'margin': '0 auto',
        'padding': '20px',
        'fontFamily': 'Arial, sans-serif',
    },
    'header': {
        'textAlign': 'center',
        'color': '#4CAF50',
        'marginBottom': '20px',
    },
    'kpi': {
        'backgroundColor': '#f9f9f9',
        'padding': '20px',
        'borderRadius': '5px',
        'textAlign': 'center',
        'marginBottom': '20px',
        'boxShadow': '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    'insights': {
        'backgroundColor': '#f1f1f1',
        'padding': '20px',
        'borderRadius': '5px',
        'marginTop': '20px',
        'boxShadow': '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    'graph': {
        'marginTop': '20px',
        'boxShadow': '0 2px 4px rgba(0, 0, 0, 0.1)',
        'borderRadius': '5px',
        'padding': '10px',
        'backgroundColor': '#fff',
    },
    'footer': {
        'textAlign': 'center',
        'marginTop': '50px',
        'padding': '20px',
        'backgroundColor': '#4CAF50',
        'color': '#fff',
    }
}

# Define the layout of the dashboard
app.layout = html.Div([
    html.H1('Sales Predictive Dashboard', style=styles['header']),
    
    # KPIs
    html.Div([
        html.Div([
            html.H3('Total Revenue'),
            html.P(f"${monthly_sales['Revenue'].sum():,.2f}"),
        ], className='four columns', style=styles['kpi']),
        
        html.Div([
            html.H3('Forecasted Revenue (Next 4 Months)'),
            html.P(f"${future_forecast.sum():,.2f}"),
        ], className='four columns', style=styles['kpi']),

        html.Div([
            html.H3('Products in Revenue Categories'),
            dcc.Graph(id='category-counts', 
                      figure={
                          'data': [
                              go.Bar(x=category_counts['Revenue Category'], y=category_counts['Number of Products'],
                                     text=category_counts['Number of Products'], textposition='auto')
                          ],
                          'layout': go.Layout(
                              title='Product Distribution by Revenue Category',
                              xaxis={'title': 'Revenue Category'},
                              yaxis={'title': 'Number of Products'},
                              plot_bgcolor='rgba(0,0,0,0)',
                              paper_bgcolor='rgba(0,0,0,0)',
                              font={'color': '#333'},
                          )
                      }),
        ], className='four columns', style=styles['kpi']),
    ], className='row'),

    # Trends Plot
    html.Div([
        dcc.Graph(id='revenue-trends', 
                  figure={
                      'data': [
                          go.Scatter(x=plot_data['MonthYear'], y=plot_data['Revenue'],
                                     mode='lines', name='Actual Revenue'),
                          go.Scatter(x=plot_data['MonthYear'], y=plot_data['Revenue_MA'],
                                     mode='lines', name='3-Month Moving Average'),
                          go.Scatter(x=plot_data['MonthYear'], y=plot_data['Forecasted_Revenue_Lin'],
                                     mode='lines', name='Forecasted Revenue')
                      ],
                      'layout': go.Layout(
                          title='Revenue Trends',
                          xaxis={'title': 'Month-Year'},
                          yaxis={'title': 'Revenue'},
                          hovermode='closest',
                          plot_bgcolor='rgba(0,0,0,0)',
                          paper_bgcolor='rgba(0,0,0,0)',
                          font={'color': '#333'},
                      )
                  }),
    ], style=styles['graph']),

    # Insights and Recommendations
    html.Div([
        html.H2('Insights and Recommendations'),
        html.P('1. Focus on high-performing products based on sales trends.'),
        html.P('2. Adjust marketing strategies to boost sales in low-performing months.'),
        html.P('3. Use inventory management to optimize stock levels based on forecasted demand.')
    ], style=styles['insights']),

    # Footer
    html.Div([
        html.P('Kyndryl - 2024'),
    ], style=styles['footer']),
    
], style=styles['container'])

# Run the app
if __name__ == '__main__':
    app.run_server(debug=Tru, port=8026)
