import numpy as np
import pandas as pd
import plotly.graph_objs as go
from sklearn.neighbors import KNeighborsRegressor

# Sample data (replace this with your actual data)
np.random.seed(0)
dates = pd.date_range('2021-01-01', periods=24, freq='M')
revenue = np.random.randint(20000, 40000, size=24)

df = pd.DataFrame({'Date': dates, 'Revenue': revenue})

# KNN Model for Forecasting
X = np.arange(len(df)).reshape(-1, 1)  # Using the index as X
y = df['Revenue'].values
knn_model = KNeighborsRegressor(n_neighbors=3)
knn_model.fit(X, y)

# Forecasting next 4 months
forecast_X = np.arange(len(df), len(df) + 4).reshape(-1, 1)
forecast_revenue = knn_model.predict(forecast_X)

# Plotly Line Graph with Dots
fig = go.Figure()

# Plot actual revenue data
fig.add_trace(go.Scatter(
    x=df['Date'],
    y=df['Revenue'],
    mode='lines+markers',
    name='Actual Revenue'
))

# Plot forecasted revenue data
forecast_dates = pd.date_range(df['Date'].iloc[-1] + pd.DateOffset(months=1), periods=4, freq='M')
fig.add_trace(go.Scatter(
    x=forecast_dates,
    y=forecast_revenue,
    mode='lines+markers',
    name='Forecasted Revenue',
    line=dict(dash='dash', color='orange')  # Dotted line for forecast
))

# Layout settings
fig.update_layout(
    title='KNN Revenue Forecast',
    xaxis_title='Date',
    yaxis_title='Revenue',
    height=400
)

# Show the figure
fig.show()
